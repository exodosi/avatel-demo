
import React, { useState, useEffect } from 'react';

interface SplashScreenProps {
  onEnter: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onEnter }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(true);
    }, 500); // Delay for the button to appear

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-900">
      <div className={`transition-all duration-1000 ease-in-out ${visible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
        <button
          onClick={onEnter}
          className="
            px-16 py-6 
            text-4xl font-black text-white 
            bg-gradient-to-br from-cyan-400 to-teal-600 
            rounded-2xl 
            shadow-lg shadow-cyan-500/40 
            hover:shadow-xl hover:shadow-cyan-400/60
            focus:outline-none focus:ring-4 focus:ring-cyan-300
            transform hover:scale-105 transition-transform duration-300
            border-2 border-cyan-300/50
            "
        >
          avatel
        </button>
      </div>
    </div>
  );
};

export default SplashScreen;
