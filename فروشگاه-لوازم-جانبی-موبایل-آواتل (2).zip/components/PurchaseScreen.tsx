import React, { useState, useMemo } from 'react';
import { InvoiceItem } from '../types';
import BackButton from './common/BackButton';
import WhatsAppIcon from './icons/WhatsAppIcon';
import EditIcon from './icons/EditIcon';

interface PurchaseScreenProps {
  onBack: () => void;
}

const PHONE_NUMBER = "989917137875"; // NOTE: Replace with the actual phone number
const DISCOUNT_RATE = 0.064;

const PurchaseScreen: React.FC<PurchaseScreenProps> = ({ onBack }) => {
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState('1');

  // State for editing an item
  const [editingItemId, setEditingItemId] = useState<number | null>(null);
  const [editedName, setEditedName] = useState('');
  const [editedPrice, setEditedPrice] = useState('');
  const [editedQuantity, setEditedQuantity] = useState('');

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(newItemPrice);
    const quantity = parseInt(newItemQuantity, 10);
    if (newItemName.trim() && !isNaN(price) && price > 0 && !isNaN(quantity) && quantity > 0) {
      const newItem: InvoiceItem = {
        id: Date.now(),
        name: newItemName.trim(),
        price: price,
        quantity: quantity,
      };
      setItems([...items, newItem]);
      setNewItemName('');
      setNewItemPrice('');
      setNewItemQuantity('1');
    }
  };

  const handleRemoveItem = (id: number) => {
    setItems(items.filter(item => item.id !== id));
  };
  
  const handleStartEdit = (item: InvoiceItem) => {
      setEditingItemId(item.id);
      setEditedName(item.name);
      setEditedPrice(String(item.price));
      setEditedQuantity(String(item.quantity));
  };
  
  const handleCancelEdit = () => {
      setEditingItemId(null);
      setEditedName('');
      setEditedPrice('');
      setEditedQuantity('');
  };

  const handleSaveEdit = (id: number) => {
      const price = parseFloat(editedPrice);
      const quantity = parseInt(editedQuantity, 10);
      if (editedName.trim() && !isNaN(price) && price > 0 && !isNaN(quantity) && quantity > 0) {
          setItems(items.map(item => 
              item.id === id 
                  ? { ...item, name: editedName.trim(), price, quantity } 
                  : item
          ));
          handleCancelEdit();
      } else {
          alert("لطفاً مقادیر معتبر برای ویرایش وارد کنید.");
      }
  };


  const { subtotal, discount, total } = useMemo(() => {
    const subtotal = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const totalQuantity = items.reduce((acc, item) => acc + item.quantity, 0);
    const discount = totalQuantity > 2 ? subtotal * DISCOUNT_RATE : 0;
    const total = subtotal - discount;
    return { subtotal, discount, total };
  }, [items]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount) + ' تومان';
  };

  const generateWhatsAppMessage = () => {
    let message = "پیش فاکتور فروشگاه آواتل:\n\n";
    items.forEach((item, index) => {
      message += `${index + 1}. ${item.name}\n`;
      message += `   (تعداد: ${item.quantity} × ${formatCurrency(item.price)}) = ${formatCurrency(item.price * item.quantity)}\n`;
    });
    message += "\n----------------------\n";
    message += `جمع کل: ${formatCurrency(subtotal)}\n`;
    if (discount > 0) {
      message += `تخفیف (${(DISCOUNT_RATE * 100).toFixed(1)}%): -${formatCurrency(discount)}\n`;
    }
    message += `مبلغ نهایی: ${formatCurrency(total)}\n`;
    message += "\nبا تشکر از خرید شما!";
    return encodeURIComponent(message);
  };
  
  const handleSendToWhatsApp = () => {
      if (items.length === 0) {
          alert('لطفاً حداقل یک کالا به لیست اضافه کنید.');
          return;
      }
      const message = generateWhatsAppMessage();
      const whatsappUrl = `https://wa.me/${PHONE_NUMBER}?text=${message}`;
      window.open(whatsappUrl, '_blank');
  };
  
  const inputClasses = "w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition";
  const editInputClasses = "w-full bg-gray-600 border border-gray-500 rounded-md px-2 py-1 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition text-sm";


  return (
    <div className="relative min-h-screen bg-slate-900 p-4 md:p-6 pb-32">
      <BackButton onClick={onBack} />
      
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-3xl font-black text-cyan-400 mt-10 mb-2">خرید مستقیم</h1>
        <p className="text-lg font-bold text-white bg-gray-800/50 border-2 border-teal-500/50 rounded-xl p-3 mb-8">
          با خرید بیش از ۲ عدد کالا، صاحب <span className="text-yellow-300">۶.۴٪</span> تخفیف بشوید!
        </p>

        <form onSubmit={handleAddItem} className="bg-gray-800 p-4 rounded-xl shadow-lg mb-8 space-y-4">
          <h2 className="text-xl font-bold text-right mb-2">افزودن کالا</h2>
          <div>
            <input type="text" value={newItemName} onChange={(e) => setNewItemName(e.target.value)} placeholder="نام کالا" className={inputClasses} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <input type="number" value={newItemQuantity} onChange={(e) => setNewItemQuantity(e.target.value)} placeholder="تعداد" min="1" className={inputClasses} required />
             <input type="number" value={newItemPrice} onChange={(e) => setNewItemPrice(e.target.value)} placeholder="قیمت هر عدد (تومان)" className={inputClasses} required />
          </div>
          <button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-lg transition">
            افزودن به لیست
          </button>
        </form>

        <div className="bg-gray-800 p-4 rounded-xl shadow-lg mb-8">
            <h2 className="text-xl font-bold text-right mb-4">لیست خرید</h2>
            {items.length === 0 ? (
                <p className="text-gray-400 text-center py-4">هنوز کالایی اضافه نشده است.</p>
            ) : (
                <ul className="space-y-3">
                    {items.map((item) => (
                      editingItemId === item.id ? (
                        <li key={item.id} className="bg-gray-700/50 p-3 rounded-lg ring-2 ring-cyan-500">
                          <div className="space-y-2">
                            <input type="text" value={editedName} onChange={(e) => setEditedName(e.target.value)} className={editInputClasses} placeholder="نام کالا"/>
                            <div className="grid grid-cols-2 gap-2">
                              <input type="number" value={editedQuantity} onChange={(e) => setEditedQuantity(e.target.value)} min="1" className={editInputClasses} placeholder="تعداد" />
                              <input type="number" value={editedPrice} onChange={(e) => setEditedPrice(e.target.value)} min="0" className={editInputClasses} placeholder="قیمت" />
                            </div>
                          </div>
                          <div className="flex justify-end gap-2 mt-3">
                            <button onClick={handleCancelEdit} className="text-gray-400 hover:text-white px-3 py-1 rounded text-sm">لغو</button>
                            <button onClick={() => handleSaveEdit(item.id)} className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold px-3 py-1 rounded text-sm">ذخیره</button>
                          </div>
                        </li>
                      ) : (
                        <li key={item.id} onClick={() => handleStartEdit(item)} className="flex justify-between items-center bg-gray-700 p-3 rounded-lg transition-colors hover:bg-gray-600 cursor-pointer">
                            <div className="text-right flex-grow">
                                <p className="font-semibold">{item.name} <span className="text-sm text-cyan-400 font-mono">x{item.quantity}</span></p>
                                <p className="text-sm text-gray-300">{formatCurrency(item.price * item.quantity)}</p>
                                {item.quantity > 1 && <p className="text-xs text-gray-500">({formatCurrency(item.price)} هر عدد)</p>}
                            </div>
                            <div className="flex items-center flex-shrink-0 ml-4">
                                <div className="text-gray-400 hover:text-cyan-400 p-2" aria-label="ویرایش">
                                    <EditIcon className="w-5 h-5" />
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); handleRemoveItem(item.id); }} className="text-red-400 hover:text-red-500 p-2" aria-label="حذف">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </div>
                        </li>
                      )
                    ))}
                </ul>
            )}
        </div>
        
        {items.length > 0 && (
            <div className="bg-gray-800 p-4 rounded-xl shadow-lg text-right space-y-3">
                <div className="flex justify-between items-center"><span className="font-semibold">جمع کل:</span><span>{formatCurrency(subtotal)}</span></div>
                 {discount > 0 && (<div className="flex justify-between items-center text-green-400"><span className="font-semibold">تخفیف:</span><span>- {formatCurrency(discount)}</span></div>)}
                 <div className="border-t border-gray-600 my-2"></div>
                 <div className="flex justify-between items-center text-2xl font-black text-cyan-400"><span className="font-semibold">مبلغ نهایی:</span><span>{formatCurrency(total)}</span></div>
            </div>
        )}
      </div>

       <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-slate-900 via-slate-900 to-transparent">
            <div className="max-w-2xl mx-auto">
                <button onClick={handleSendToWhatsApp} className="w-full flex items-center justify-center gap-3 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-xl shadow-lg shadow-green-500/30 transition transform hover:scale-105">
                    <WhatsAppIcon className="w-6 h-6" />
                    <span>تایید و ارسال به واتساپ</span>
                </button>
            </div>
       </div>
    </div>
  );
};

export default PurchaseScreen;