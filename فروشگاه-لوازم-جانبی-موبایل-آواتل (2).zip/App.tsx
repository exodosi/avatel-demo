import React, { useState } from 'react';
import { AppScreen } from './types';
import SplashScreen from './components/SplashScreen';
import MainScreen from './components/MainScreen';
import PurchaseScreen from './components/PurchaseScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.Splash);

  const renderScreen = () => {
    switch (currentScreen) {
      case AppScreen.Splash:
        return <SplashScreen onEnter={() => setCurrentScreen(AppScreen.Main)} />;
      case AppScreen.Main:
        return <MainScreen onNavigateToPurchase={() => setCurrentScreen(AppScreen.Purchase)} />;
      case AppScreen.Purchase:
        return <PurchaseScreen onBack={() => setCurrentScreen(AppScreen.Main)} />;
      default:
        return <SplashScreen onEnter={() => setCurrentScreen(AppScreen.Main)} />;
    }
  };

  return (
    <div className="bg-slate-900 text-white min-h-screen w-full font-['Vazirmatn']">
      {renderScreen()}
    </div>
  );
};

export default App;