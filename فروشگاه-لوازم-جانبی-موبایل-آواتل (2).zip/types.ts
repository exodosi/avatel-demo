export enum AppScreen {
  Splash,
  Main,
  Purchase,
}

export interface InvoiceItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}